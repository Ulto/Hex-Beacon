This footprint is for Tag Connect TC2030-MCP-NL connector.
For Cadence Orcad PCB Editor 16.2.
From phil@dektron.com
www.dektron.com
24 Aug 2009
