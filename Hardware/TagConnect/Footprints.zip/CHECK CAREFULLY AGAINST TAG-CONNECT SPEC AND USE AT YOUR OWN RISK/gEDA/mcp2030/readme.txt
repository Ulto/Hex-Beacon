Tag Connect TC2030-MCP Micochip Programing Header gEDA PCB Library

Design by Rudolf Bodocsi
www.bodocsi.net

License: http://www.gnu.org/licenses/gpl.html

Please chehck gEDA PCB documentation how to install and use this footprint library.

