
The OrCAD files here were provided by Jay Helmericks of the UAF/Geophysical Institute

Contains Orcad schematic and layout files.  There are footprints for both non-plated and plated mounting holes.
The gerbers show all four footprint options in one file.




