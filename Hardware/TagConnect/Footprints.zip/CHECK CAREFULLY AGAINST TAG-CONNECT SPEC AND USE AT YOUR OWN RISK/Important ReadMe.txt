These files are user supplied and are NOT guaranteed by Tag-Connect as being correct.

1. Carefully check the footprints against our datasheets.
2. Check that the pin numbering is correct.
3. Check that there is no hole in the solder paste mask layer
4. Check all dimensions.
5. Review the datasheet for the common layout problems illustrated.

Please let us know if you find any mistakes.
