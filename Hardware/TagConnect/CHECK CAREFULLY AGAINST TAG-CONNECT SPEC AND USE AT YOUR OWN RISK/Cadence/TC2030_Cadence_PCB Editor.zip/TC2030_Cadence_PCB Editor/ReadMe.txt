
The PCB Editor files here were provided by Marco Cattapan of the Pizzato Elettrica srl.

Contains Cadence PCB Editor (v16.3) footprints of TC2030_MCP and TC2030_MCP_NL.

The footprints are for non-plated mounting holes.

The gerbers show all two footprint options in one file (PCB Editor file included).

The layers are:

- TOP
- BOTTOM
- SOLDERMASK_TOP
- SOLDERMASK_BOTTOM
- DRILL
- PASTEMASK_TOP	(empty)
- PASTEMASK_BOTTOM (empty)




