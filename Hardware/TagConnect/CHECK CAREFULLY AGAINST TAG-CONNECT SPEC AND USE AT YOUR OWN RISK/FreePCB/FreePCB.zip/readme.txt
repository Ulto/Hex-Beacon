These FreePCB footprints were provided by Guy Fernando of Informatix, http://www.informatix.net

History
-------

31 March 2010 - Created.
20 April 2010 - Applied changes outlined in Tag-Connect Rev.D drawings.


Files
-----

CAM             - Folder containing test example gerber and drill files.
readme.txt      - This file.
tag_connect.fpc - FreePCB PCB test example containing the Tag-Connect footprints.
tag_connect.fpl - FreePCB Tag-Connect footprints.
tag_connect.pdf - PDF containing FreePCB Tag-Connect footprint descriptions.


Using these footprints
----------------------

1) Start the FreePCB application.
2) Open your PCB design.
3) Select the Add | Part menu option.
4) Click the browse button, and select the folder in which the tag_connect.fpl footprint library was saved.
5) Expand the tag_connect.fpl footprint library and select the required footprint.
6) Click the OK button.
7) Place the chosen footprint over your PCB design.
7) Done.