
To import these Decals into PADS:

1. Open the Library Manager.
2. Select the library you want to import to.
3. Select Decals.
4. Select Import... and choose the TC2050-IDC.d file.

To ipmprt the part type intp PADS:

1. Open the Library Manager.
2. Select the library you want to import to.
3. Select Parts.
4. Select Import... and choose the TC2050-IDC.p file.
 