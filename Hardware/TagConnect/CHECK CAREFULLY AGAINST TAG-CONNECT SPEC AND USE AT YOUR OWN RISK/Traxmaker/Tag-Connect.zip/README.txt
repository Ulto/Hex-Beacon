1. Open the 'tag connect.pcb' file with TraxMaker
2. Click on one of the two parts.
3. Click on the place component icon.
4. Click Add
5. Name it what ever you like and click OK
6. Do the same with the other part if you so desire.
7. You are done. You now have a tag connect component(s) in TraxMaker